const express = require('express');
const app = express();
const fetch = require('node-fetch');


app.get('/',(req, res)=>{
  fetch('https://localhost:3000/usuario/')
  .then(response => response.json())
  .then(data => console.log(data));
})

app.listen(8000, ()=>{
  console.log("rodando servidor na porta 8000")
})
