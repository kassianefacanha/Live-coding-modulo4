const bd = {
    "usuario": [],
    "tarefa": []
}

module.exports = bd