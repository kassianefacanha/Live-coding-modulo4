const request = require('supertest')
const ApiUrl = "https://gorest.co.in/public/v2";


describe('Teste rota Usuario GET',()=>{
    test('Testando status 200', ()=>{
        return request(ApiUrl).get('/users')
        .then((response)=>{
            expect(response.statusCode).toBe(200)
        })
    })
})
